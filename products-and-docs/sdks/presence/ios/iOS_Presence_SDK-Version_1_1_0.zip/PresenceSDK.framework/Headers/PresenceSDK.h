//
//  PresenceSDK.h
//  PresenceSDK
//
//  Created by Michael Estes on 7/19/17.
//  Copyright © 2017 Ticketmaster. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PresenceSDK.
FOUNDATION_EXPORT double PresenceSDKVersionNumber;

//! Project version string for PresenceSDK.
FOUNDATION_EXPORT const unsigned char PresenceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PresenceSDK/PublicHeader.h>


